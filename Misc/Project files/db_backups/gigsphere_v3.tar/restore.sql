--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE gigsphere;
--
-- Name: gigsphere; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE gigsphere WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE gigsphere OWNER TO postgres;

\connect gigsphere

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    client_id character(10) NOT NULL,
    company_name character varying(50),
    business_type character varying(50)
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: contract_modifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contract_modifications (
    modification_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    contract_id character(10),
    modified_by character(10),
    modified_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    old_price numeric(10,2),
    new_price numeric(10,2),
    old_deadline date,
    new_deadline date,
    status character varying(50),
    CONSTRAINT contract_modifications_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.contract_modifications OWNER TO postgres;

--
-- Name: contracts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contracts (
    contract_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    client_id character(10),
    freelancer_id character(10),
    project_id character(10),
    proposal_id character(10),
    agreed_price numeric(10,2),
    start_date date NOT NULL,
    end_date date,
    status character varying(50),
    CONSTRAINT contracts_agreed_price_check CHECK ((agreed_price >= (0)::numeric)),
    CONSTRAINT contracts_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.contracts OWNER TO postgres;

--
-- Name: endorsements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endorsements (
    endorsement_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    client_id character(10),
    freelancer_id character(10),
    endorsement_text text
);


ALTER TABLE public.endorsements OWNER TO postgres;

--
-- Name: freelancer_skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.freelancer_skills (
    skill_id character(10) NOT NULL,
    freelancer_id character(10) NOT NULL
);


ALTER TABLE public.freelancer_skills OWNER TO postgres;

--
-- Name: freelancers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.freelancers (
    freelancer_id character(10) NOT NULL,
    bio text,
    portfolio text,
    experience integer,
    hourly_rate numeric(10,2),
    CONSTRAINT freelancers_experience_check CHECK ((experience >= 0)),
    CONSTRAINT freelancers_hourly_rate_check CHECK ((hourly_rate >= (0)::numeric))
);


ALTER TABLE public.freelancers OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    invoice_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    contract_id character(10),
    net_amount numeric(10,2),
    issued_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    due_date date NOT NULL,
    status character varying(50),
    paid_at timestamp without time zone,
    CONSTRAINT invoices_net_amount_check CHECK ((net_amount >= (0)::numeric)),
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'overdue'::character varying])::text[])))
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    payment_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    contract_id character(10),
    amount numeric(10,2),
    payment_method character varying(100) NOT NULL,
    status character varying(50),
    CONSTRAINT payments_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT payments_status_check CHECK (((status)::text = ANY ((ARRAY['completed'::character varying, 'failed'::character varying])::text[])))
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.projects (
    project_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    client_id character(10),
    title character varying(200),
    description text,
    budget numeric(10,2),
    deadline date NOT NULL,
    posted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50),
    CONSTRAINT projects_budget_check CHECK ((budget >= (0)::numeric)),
    CONSTRAINT projects_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in progress'::character varying, 'completed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.projects OWNER TO postgres;

--
-- Name: proposals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proposals (
    proposal_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    freelancer_id character(10),
    project_id character(10),
    proposal_text text NOT NULL,
    bid_amount numeric(10,2),
    submitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT proposals_bid_amount_check CHECK ((bid_amount >= (0)::numeric))
);


ALTER TABLE public.proposals OWNER TO postgres;

--
-- Name: reviews; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reviews (
    review_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    reviewer_id character(10),
    reviewee_id character(10),
    review_text text,
    rating integer,
    review_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.reviews OWNER TO postgres;

--
-- Name: skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skills (
    skill_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    skill_name character varying(200) NOT NULL
);


ALTER TABLE public.skills OWNER TO postgres;

--
-- Name: submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.submissions (
    submission_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    submitted_by character(10),
    contract_id character(10),
    description text,
    submitted_file character varying(500),
    submitted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approved boolean DEFAULT false
);


ALTER TABLE public.submissions OWNER TO postgres;

--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    ticket_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    raised_by character(10),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    subject character varying(300) NOT NULL,
    description text NOT NULL,
    status character varying(50),
    resolved_at timestamp without time zone,
    CONSTRAINT support_tickets_status_check CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'in progress'::character varying, 'resolved'::character varying, 'closed'::character varying])::text[])))
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    username character varying(20) NOT NULL,
    email character varying(100) NOT NULL,
    user_type character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    password_hash character varying(50) NOT NULL,
    CONSTRAINT users_user_type_check CHECK (((user_type)::text = ANY ((ARRAY['client'::character varying, 'freelancer'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: withdrawals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.withdrawals (
    withdrawal_id character(10) DEFAULT SUBSTRING((gen_random_uuid())::text FROM 1 FOR 10) NOT NULL,
    requested_by character(10),
    approved_by character(10),
    contract_id character(10),
    reason text,
    status character varying(50),
    withdrawn_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT withdrawals_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.withdrawals OWNER TO postgres;

--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (client_id, company_name, business_type) FROM stdin;
\.
COPY public.clients (client_id, company_name, business_type) FROM '$$PATH$$/5039.dat';

--
-- Data for Name: contract_modifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contract_modifications (modification_id, contract_id, modified_by, modified_at, old_price, new_price, old_deadline, new_deadline, status) FROM stdin;
\.
COPY public.contract_modifications (modification_id, contract_id, modified_by, modified_at, old_price, new_price, old_deadline, new_deadline, status) FROM '$$PATH$$/5048.dat';

--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contracts (contract_id, client_id, freelancer_id, project_id, proposal_id, agreed_price, start_date, end_date, status) FROM stdin;
\.
COPY public.contracts (contract_id, client_id, freelancer_id, project_id, proposal_id, agreed_price, start_date, end_date, status) FROM '$$PATH$$/5047.dat';

--
-- Data for Name: endorsements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endorsements (endorsement_id, client_id, freelancer_id, endorsement_text) FROM stdin;
\.
COPY public.endorsements (endorsement_id, client_id, freelancer_id, endorsement_text) FROM '$$PATH$$/5046.dat';

--
-- Data for Name: freelancer_skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.freelancer_skills (skill_id, freelancer_id) FROM stdin;
\.
COPY public.freelancer_skills (skill_id, freelancer_id) FROM '$$PATH$$/5043.dat';

--
-- Data for Name: freelancers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.freelancers (freelancer_id, bio, portfolio, experience, hourly_rate) FROM stdin;
\.
COPY public.freelancers (freelancer_id, bio, portfolio, experience, hourly_rate) FROM '$$PATH$$/5041.dat';

--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (invoice_id, contract_id, net_amount, issued_at, due_date, status, paid_at) FROM stdin;
\.
COPY public.invoices (invoice_id, contract_id, net_amount, issued_at, due_date, status, paid_at) FROM '$$PATH$$/5050.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (payment_id, contract_id, amount, payment_method, status) FROM stdin;
\.
COPY public.payments (payment_id, contract_id, amount, payment_method, status) FROM '$$PATH$$/5049.dat';

--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.projects (project_id, client_id, title, description, budget, deadline, posted_at, status) FROM stdin;
\.
COPY public.projects (project_id, client_id, title, description, budget, deadline, posted_at, status) FROM '$$PATH$$/5040.dat';

--
-- Data for Name: proposals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proposals (proposal_id, freelancer_id, project_id, proposal_text, bid_amount, submitted_at) FROM stdin;
\.
COPY public.proposals (proposal_id, freelancer_id, project_id, proposal_text, bid_amount, submitted_at) FROM '$$PATH$$/5044.dat';

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reviews (review_id, reviewer_id, reviewee_id, review_text, rating, review_date) FROM stdin;
\.
COPY public.reviews (review_id, reviewer_id, reviewee_id, review_text, rating, review_date) FROM '$$PATH$$/5045.dat';

--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skills (skill_id, skill_name) FROM stdin;
\.
COPY public.skills (skill_id, skill_name) FROM '$$PATH$$/5042.dat';

--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.submissions (submission_id, submitted_by, contract_id, description, submitted_file, submitted_at, approved) FROM stdin;
\.
COPY public.submissions (submission_id, submitted_by, contract_id, description, submitted_file, submitted_at, approved) FROM '$$PATH$$/5051.dat';

--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (ticket_id, raised_by, created_at, subject, description, status, resolved_at) FROM stdin;
\.
COPY public.support_tickets (ticket_id, raised_by, created_at, subject, description, status, resolved_at) FROM '$$PATH$$/5053.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, username, email, user_type, created_at, password_hash) FROM stdin;
\.
COPY public.users (user_id, username, email, user_type, created_at, password_hash) FROM '$$PATH$$/5038.dat';

--
-- Data for Name: withdrawals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.withdrawals (withdrawal_id, requested_by, approved_by, contract_id, reason, status, withdrawn_at) FROM stdin;
\.
COPY public.withdrawals (withdrawal_id, requested_by, approved_by, contract_id, reason, status, withdrawn_at) FROM '$$PATH$$/5052.dat';

--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (client_id);


--
-- Name: contract_modifications contract_modifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contract_modifications
    ADD CONSTRAINT contract_modifications_pkey PRIMARY KEY (modification_id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (contract_id);


--
-- Name: endorsements endorsements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endorsements
    ADD CONSTRAINT endorsements_pkey PRIMARY KEY (endorsement_id);


--
-- Name: freelancer_skills freelancer_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freelancer_skills
    ADD CONSTRAINT freelancer_skills_pkey PRIMARY KEY (skill_id, freelancer_id);


--
-- Name: freelancers freelancers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freelancers
    ADD CONSTRAINT freelancers_pkey PRIMARY KEY (freelancer_id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (invoice_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (project_id);


--
-- Name: proposals proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT proposals_pkey PRIMARY KEY (proposal_id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (review_id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (skill_id);


--
-- Name: skills skills_skill_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_skill_name_key UNIQUE (skill_name);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (submission_id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (ticket_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: withdrawals withdrawals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_pkey PRIMARY KEY (withdrawal_id);


--
-- Name: clients clients_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: contract_modifications contract_modifications_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contract_modifications
    ADD CONSTRAINT contract_modifications_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(contract_id) ON DELETE CASCADE;


--
-- Name: contract_modifications contract_modifications_modified_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contract_modifications
    ADD CONSTRAINT contract_modifications_modified_by_fkey FOREIGN KEY (modified_by) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: contracts contracts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(client_id) ON DELETE CASCADE;


--
-- Name: contracts contracts_freelancer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_freelancer_id_fkey FOREIGN KEY (freelancer_id) REFERENCES public.freelancers(freelancer_id) ON DELETE CASCADE;


--
-- Name: contracts contracts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: contracts contracts_proposal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_proposal_id_fkey FOREIGN KEY (proposal_id) REFERENCES public.proposals(proposal_id) ON DELETE CASCADE;


--
-- Name: endorsements endorsements_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endorsements
    ADD CONSTRAINT endorsements_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: endorsements endorsements_freelancer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endorsements
    ADD CONSTRAINT endorsements_freelancer_id_fkey FOREIGN KEY (freelancer_id) REFERENCES public.freelancers(freelancer_id) ON DELETE CASCADE;


--
-- Name: freelancer_skills freelancer_skills_freelancer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freelancer_skills
    ADD CONSTRAINT freelancer_skills_freelancer_id_fkey FOREIGN KEY (freelancer_id) REFERENCES public.freelancers(freelancer_id) ON DELETE CASCADE;


--
-- Name: freelancer_skills freelancer_skills_skill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freelancer_skills
    ADD CONSTRAINT freelancer_skills_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skills(skill_id) ON DELETE CASCADE;


--
-- Name: freelancers freelancers_freelancer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.freelancers
    ADD CONSTRAINT freelancers_freelancer_id_fkey FOREIGN KEY (freelancer_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: invoices invoices_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(contract_id) ON DELETE CASCADE;


--
-- Name: payments payments_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(contract_id) ON DELETE CASCADE;


--
-- Name: projects projects_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(client_id) ON DELETE CASCADE;


--
-- Name: proposals proposals_freelancer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT proposals_freelancer_id_fkey FOREIGN KEY (freelancer_id) REFERENCES public.freelancers(freelancer_id) ON DELETE CASCADE;


--
-- Name: proposals proposals_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT proposals_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(project_id) ON DELETE CASCADE;


--
-- Name: reviews reviews_reviewee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_reviewee_id_fkey FOREIGN KEY (reviewee_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: reviews reviews_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: submissions submissions_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(contract_id) ON DELETE CASCADE;


--
-- Name: submissions submissions_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES public.freelancers(freelancer_id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_raised_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_raised_by_fkey FOREIGN KEY (raised_by) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: withdrawals withdrawals_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: withdrawals withdrawals_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(contract_id) ON DELETE CASCADE;


--
-- Name: withdrawals withdrawals_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.withdrawals
    ADD CONSTRAINT withdrawals_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

